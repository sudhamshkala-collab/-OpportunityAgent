"""Opportunity Recommendation Agent - Flask web application."""

import os
import sqlite3
from datetime import datetime
from functools import wraps

import pandas as pd
from flask import (
    Flask,
    flash,
    g,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash

from ml.recommender import (
    learning_recommendations,
    recommend_opportunities,
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.path.join(BASE_DIR, "database", "database.db")
DATASET = os.path.join(BASE_DIR, "dataset", "opportunities.csv")

OPPORTUNITY_TYPES = ["Internship", "Job", "Hackathon", "Scholarship", "Course", "Certification"]
EXPERIENCE_LEVELS = ["Fresher", "0-1 years", "1-2 years", "2-4 years", "4+ years"]
WORK_TYPES = ["", "Remote", "On-site", "Hybrid"]

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "opportunity-agent-dev-secret")
app.config["DATABASE"] = DATABASE


# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------

def get_db():
    if "db" not in g:
        conn = sqlite3.connect(app.config["DATABASE"])
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        g.db = conn
    return g.db


@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(app.config["DATABASE"])
    c = conn.cursor()

    c.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            education TEXT DEFAULT '',
            degree TEXT DEFAULT '',
            branch TEXT DEFAULT '',
            skills TEXT DEFAULT '',
            programming_languages TEXT DEFAULT '',
            experience TEXT DEFAULT 'Fresher',
            projects TEXT DEFAULT '',
            interests TEXT DEFAULT '',
            preferred_role TEXT DEFAULT '',
            location TEXT DEFAULT '',
            work_type TEXT DEFAULT '',
            is_admin INTEGER DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS opportunities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            company TEXT DEFAULT '',
            description TEXT DEFAULT '',
            type TEXT DEFAULT '',
            skills TEXT DEFAULT '',
            education TEXT DEFAULT '',
            experience TEXT DEFAULT '',
            location TEXT DEFAULT '',
            application_url TEXT DEFAULT '',
            deadline TEXT DEFAULT ''
        );

        CREATE TABLE IF NOT EXISTS recommendations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            opportunity_id INTEGER NOT NULL,
            score REAL DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (opportunity_id) REFERENCES opportunities(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS applications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            opportunity_id INTEGER NOT NULL,
            status TEXT DEFAULT 'Applied',
            applied_date TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (opportunity_id) REFERENCES opportunities(id) ON DELETE CASCADE
        );
        """
    )
    conn.commit()

    # Seed default admin
    admin = c.execute("SELECT id FROM users WHERE email = ?", ("admin@example.com",)).fetchone()
    if admin is None:
        c.execute(
            "INSERT INTO users (name, email, password_hash, skills, education, "
            "branch, interests, preferred_role, is_admin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)",
            (
                "Administrator",
                "admin@example.com",
                generate_password_hash("admin123"),
                "Python, Flask, SQL",
                "B.Tech",
                "CSE",
                "Artificial Intelligence",
                "Platform Management",
            ),
        )

    # Seed opportunities from CSV if the table is empty
    count = c.execute("SELECT COUNT(*) FROM opportunities").fetchone()[0]
    if count == 0 and os.path.exists(DATASET):
        df = pd.read_csv(DATASET)
        for _, row in df.iterrows():
            c.execute(
                "INSERT INTO opportunities (title, company, description, type, skills, "
                "education, experience, location, application_url, deadline) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    str(row.get("title", "")),
                    str(row.get("company", "")),
                    str(row.get("description", "")),
                    str(row.get("type", "")),
                    str(row.get("skills", "")),
                    str(row.get("education", "")),
                    str(row.get("experience", "")),
                    str(row.get("location", "")),
                    str(row.get("application_url", "")),
                    str(row.get("deadline", "")),
                ),
            )
        conn.commit()

    conn.close()


def opportunities_dataframe():
    conn = sqlite3.connect(app.config["DATABASE"])
    try:
        df = pd.read_sql_query("SELECT * FROM opportunities", conn)
    finally:
        conn.close()
    return df


def user_profile_dict(row):
    return {
        "skills": row["skills"],
        "programming_languages": row["programming_languages"],
        "education": row["education"],
        "degree": row["degree"],
        "branch": row["branch"],
        "experience": row["experience"],
        "projects": row["projects"],
        "interests": row["interests"],
        "preferred_role": row["preferred_role"],
        "location": row["location"],
        "work_type": row["work_type"],
    }


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("user_id") is None:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)

    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("user_id") is None:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        if not session.get("is_admin"):
            flash("You do not have admin access.", "danger")
            return redirect(url_for("dashboard"))
        return view(*args, **kwargs)

    return wrapped


@app.route("/")
def index():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        if not name or not email or not password:
            flash("Name, email and password are required.", "danger")
            return render_template("register.html")

        db = get_db()
        if db.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone():
            flash("An account with that email already exists.", "warning")
            return render_template("register.html")

        db.execute(
            "INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)",
            (name, email, generate_password_hash(password)),
        )
        db.commit()
        flash("Account created! Please log in.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        user = get_db().execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            session["name"] = user["name"]
            session["is_admin"] = bool(user["is_admin"])
            flash(f"Welcome back, {user['name']}!", "success")
            return redirect(url_for("dashboard"))

        flash("Invalid email or password.", "danger")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))


# ---------------------------------------------------------------------------
# Profile
# ---------------------------------------------------------------------------

@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchone()

    if request.method == "POST":
        fields = [
            "name", "education", "degree", "branch", "skills",
            "programming_languages", "experience", "projects",
            "interests", "preferred_role", "location", "work_type",
        ]
        values = {f: request.form.get(f, "").strip() for f in fields}
        db.execute(
            "UPDATE users SET name = ?, education = ?, degree = ?, branch = ?, skills = ?, "
            "programming_languages = ?, experience = ?, projects = ?, interests = ?, "
            "preferred_role = ?, location = ?, work_type = ? WHERE id = ?",
            (
                values["name"], values["education"], values["degree"], values["branch"],
                values["skills"], values["programming_languages"], values["experience"],
                values["projects"], values["interests"], values["preferred_role"],
                values["location"], values["work_type"], session["user_id"],
            ),
        )
        db.commit()
        session["name"] = values["name"]
        flash("Your profile has been updated.", "success")
        return redirect(url_for("profile"))

    return render_template(
        "profile.html",
        user=user,
        experience_levels=EXPERIENCE_LEVELS,
        work_types=WORK_TYPES,
    )


# ---------------------------------------------------------------------------
# Recommendations / Dashboard
# ---------------------------------------------------------------------------

def compute_recommendations(user_id, top_n=10, filters=None):
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    df = opportunities_dataframe()
    results = recommend_opportunities(user_profile_dict(user), df, top_n=top_n, filters=filters)
    return user, results


@app.route("/dashboard")
@login_required
def dashboard():
    user, results = compute_recommendations(session["user_id"], top_n=10)

    # Persist the top recommendations for stats + history
    db = get_db()
    db.execute("DELETE FROM recommendations WHERE user_id = ?", (session["user_id"],))
    for r in results:
        db.execute(
            "INSERT INTO recommendations (user_id, opportunity_id, score) VALUES (?, ?, ?)",
            (session["user_id"], r["id"], r["score"]),
        )
    db.commit()

    profile_completion = 0
    checks = [user["skills"], user["education"], user["interests"], user["preferred_role"],
              user["location"], user["experience"]]
    profile_completion = round(sum(1 for v in checks if v) / len(checks) * 100)

    return render_template("dashboard.html", user=user, recommendations=results,
                           profile_completion=profile_completion)


@app.route("/recommendations")
@login_required
def recommendations():
    filters = {
        "type": request.args.get("type", ""),
        "location": request.args.get("location", ""),
        "skills": request.args.get("skills", ""),
        "experience": request.args.get("experience", ""),
        "education": request.args.get("education", ""),
    }
    user, results = compute_recommendations(session["user_id"], top_n=50, filters=filters)
    df = opportunities_dataframe()
    available_locations = sorted(df["location"].dropna().unique().tolist())
    return render_template(
        "recommendations.html",
        user=user,
        recommendations=results,
        filters=filters,
        opportunity_types=OPPORTUNITY_TYPES,
        experience_levels=EXPERIENCE_LEVELS,
        locations=available_locations,
    )


# ---------------------------------------------------------------------------
# Opportunities
# ---------------------------------------------------------------------------

@app.route("/opportunities")
def opportunities():
    df = opportunities_dataframe()
    filters = {
        "type": request.args.get("type", ""),
        "location": request.args.get("location", ""),
        "skills": request.args.get("skills", ""),
        "experience": request.args.get("experience", ""),
        "education": request.args.get("education", ""),
        "q": request.args.get("q", ""),
    }
    from ml.recommender import filter_opportunities

    filtered = filter_opportunities(df, filters)
    available_locations = sorted(df["location"].dropna().unique().tolist())
    return render_template(
        "opportunities.html",
        rows=filtered.to_dict("records"),
        filters=filters,
        opportunity_types=OPPORTUNITY_TYPES,
        experience_levels=EXPERIENCE_LEVELS,
        locations=available_locations,
    )


@app.route("/opportunity/<int:opp_id>")
@login_required
def opportunity_detail(opp_id):
    db = get_db()
    opp = db.execute("SELECT * FROM opportunities WHERE id = ?", (opp_id,)).fetchone()
    if opp is None:
        flash("Opportunity not found.", "danger")
        return redirect(url_for("opportunities"))

    user = db.execute("SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchone()
    already_applied = db.execute(
        "SELECT id FROM applications WHERE user_id = ? AND opportunity_id = ?",
        (session["user_id"], opp_id),
    ).fetchone()

    recommendations = recommend_opportunities(
        user_profile_dict(user), opportunities_dataframe(), top_n=500
    )
    detail = next((r for r in recommendations if r["id"] == opp_id), None)

    from ml.recommender import get_skill_gap

    matched_skills, missing_skills = get_skill_gap(
        ", ".join(filter(None, [user["skills"], user["programming_languages"]])),
        opp["skills"],
    )

    skill_match_percent = round(len(matched_skills) / max(len(matched_skills) + len(missing_skills), 1) * 100)
    learning = learning_recommendations(missing_skills)

    return render_template(
        "opportunity_detail.html",
        opp=opp,
        detail=detail,
        matched_skills=matched_skills,
        missing_skills=missing_skills,
        skill_match_percent=skill_match_percent,
        learning=learning,
        already_applied=already_applied,
    )


@app.route("/opportunity/<int:opp_id>/apply", methods=["POST"])
@login_required
def apply(opp_id):
    db = get_db()
    opp = db.execute("SELECT * FROM opportunities WHERE id = ?", (opp_id,)).fetchone()
    if opp is None:
        flash("Opportunity not found.", "danger")
        return redirect(url_for("opportunities"))

    already = db.execute(
        "SELECT id FROM applications WHERE user_id = ? AND opportunity_id = ?",
        (session["user_id"], opp_id),
    ).fetchone()
    if already:
        flash("You already applied for this opportunity.", "info")
    else:
        db.execute(
            "INSERT INTO applications (user_id, opportunity_id, status) VALUES (?, ?, 'Applied')",
            (session["user_id"], opp_id),
        )
        db.commit()
        flash("Application recorded successfully!", "success")

    redirect_to = request.form.get("redirect", url_for("applications"))
    return redirect(redirect_to)


@app.route("/applications")
@login_required
def applications():
    db = get_db()
    rows = db.execute(
        """
        SELECT a.*, o.title AS opp_title, o.company AS opp_company, o.type AS opp_type,
               o.location AS opp_location, o.application_url AS opp_url, o.deadline AS opp_deadline
        FROM applications a
        JOIN opportunities o ON o.id = a.opportunity_id
        WHERE a.user_id = ?
        ORDER BY a.applied_date DESC
        """,
        (session["user_id"],),
    ).fetchall()
    stats = db.execute(
        "SELECT COUNT(*) AS total, SUM(CASE WHEN status = 'Applied' THEN 1 ELSE 0 END) AS applied "
        "FROM applications WHERE user_id = ?",
        (session["user_id"],),
    ).fetchone()
    return render_template("applications.html", rows=rows, stats=stats)


@app.route("/skill-gap")
@login_required
def skill_gap():
    user = get_db().execute("SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchone()
    recommendations = recommend_opportunities(
        user_profile_dict(user), opportunities_dataframe(), top_n=10
    )
    rows = []
    for r in recommendations:
        matched_skills, missing_skills = (
            r["matched_skills"],
            r["missing_skills"],
        )
        rows.append({
            "id": r["id"],
            "title": r["title"],
            "company": r["company"],
            "score": r["score"],
            "matched_skills": matched_skills,
            "missing_skills": missing_skills,
            "learning": learning_recommendations(missing_skills),
        })
    return render_template("skill_gap.html", user=user, rows=rows)


# ---------------------------------------------------------------------------
# Admin
# ---------------------------------------------------------------------------

@app.route("/admin")
@admin_required
def admin_dashboard():
    db = get_db()
    stats = {
        "users": db.execute("SELECT COUNT(*) FROM users").fetchone()[0],
        "opportunities": db.execute("SELECT COUNT(*) FROM opportunities").fetchone()[0],
        "recommendations": db.execute("SELECT COUNT(*) FROM recommendations").fetchone()[0],
        "applications": db.execute("SELECT COUNT(*) FROM applications").fetchone()[0],
    }
    recent_applications = db.execute(
        """
        SELECT a.applied_date, u.name AS user_name, o.title AS opp_title, o.type AS opp_type
        FROM applications a
        JOIN users u ON u.id = a.user_id
        JOIN opportunities o ON o.id = a.opportunity_id
        ORDER BY a.applied_date DESC LIMIT 8
        """
    ).fetchall()
    return render_template("admin_dashboard.html", stats=stats, recent=recent_applications)


@app.route("/admin/opportunities")
@admin_required
def admin_opportunities():
    db = get_db()
    rows = db.execute("SELECT * FROM opportunities ORDER BY id DESC").fetchall()
    return render_template("admin_opportunities.html", rows=rows)


@app.route("/admin/opportunity/new", methods=["GET", "POST"])
@app.route("/admin/opportunity/<int:opp_id>/edit", methods=["GET", "POST"])
@admin_required
def admin_opportunity_form(opp_id=None):
    db = get_db()
    opp = None
    if opp_id is not None:
        opp = db.execute("SELECT * FROM opportunities WHERE id = ?", (opp_id,)).fetchone()
        if opp is None:
            flash("Opportunity not found.", "danger")
            return redirect(url_for("admin_opportunities"))

    if request.method == "POST":
        fields = [
            "title", "company", "description", "type", "skills",
            "education", "experience", "location", "application_url", "deadline",
        ]
        values = {f: request.form.get(f, "").strip() for f in fields}
        if not values["title"]:
            flash("Title is required.", "danger")
        else:
            if opp_id is None:
                db.execute(
                    "INSERT INTO opportunities (title, company, description, type, skills, "
                    "education, experience, location, application_url, deadline) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        values["title"], values["company"], values["description"],
                        values["type"], values["skills"], values["education"],
                        values["experience"], values["location"],
                        values["application_url"], values["deadline"],
                    ),
                )
                flash("Opportunity added successfully.", "success")
            else:
                db.execute(
                    "UPDATE opportunities SET title = ?, company = ?, description = ?, type = ?, "
                    "skills = ?, education = ?, experience = ?, location = ?, "
                    "application_url = ?, deadline = ? WHERE id = ?",
                    (
                        values["title"], values["company"], values["description"],
                        values["type"], values["skills"], values["education"],
                        values["experience"], values["location"],
                        values["application_url"], values["deadline"], opp_id,
                    ),
                )
                flash("Opportunity updated successfully.", "success")
            db.commit()
            return redirect(url_for("admin_opportunities"))

    return render_template(
        "admin_opportunity_form.html",
        opp=opp,
        opportunity_types=OPPORTUNITY_TYPES,
        experience_levels=["Fresher", "0-1 years", "1-2 years", "2-4 years", "4+ years", "Student", "Beginner", "Intermediate"],
    )


@app.route("/admin/opportunity/<int:opp_id>/delete", methods=["POST"])
@admin_required
def admin_opportunity_delete(opp_id):
    db = get_db()
    db.execute("DELETE FROM opportunities WHERE id = ?", (opp_id,))
    db.execute("DELETE FROM recommendations WHERE opportunity_id = ?", (opp_id,))
    db.execute("DELETE FROM applications WHERE opportunity_id = ?", (opp_id,))
    db.commit()
    flash("Opportunity deleted.", "info")
    return redirect(url_for("admin_opportunities"))


@app.route("/admin/users")
@admin_required
def admin_users():
    db = get_db()
    users = db.execute("SELECT * FROM users ORDER BY created_at DESC").fetchall()
    return render_template("admin_users.html", users=users)


@app.route("/admin/applications")
@admin_required
def admin_applications():
    db = get_db()
    rows = db.execute(
        """
        SELECT a.*, u.name AS user_name, u.email AS user_email, o.title AS opp_title,
               o.type AS opp_type
        FROM applications a
        JOIN users u ON u.id = a.user_id
        JOIN opportunities o ON o.id = a.opportunity_id
        ORDER BY a.applied_date DESC
        """
    ).fetchall()
    return render_template("admin_applications.html", rows=rows)


@app.route("/admin/reload-data", methods=["POST"])
@admin_required
def admin_reload_data():
    if os.path.exists(DATASET):
        db = get_db()
        db.execute("DELETE FROM opportunities")
        df = pd.read_csv(DATASET)
        for _, row in df.iterrows():
            db.execute(
                "INSERT INTO opportunities (title, company, description, type, skills, "
                "education, experience, location, application_url, deadline) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    str(row.get("title", "")) if pd.notna(row.get("title", "")) else "",
                    str(row.get("company", "")) if pd.notna(row.get("company", "")) else "",
                    str(row.get("description", "")) if pd.notna(row.get("description", "")) else "",
                    str(row.get("type", "")) if pd.notna(row.get("type", "")) else "",
                    str(row.get("skills", "")) if pd.notna(row.get("skills", "")) else "",
                    str(row.get("education", "")) if pd.notna(row.get("education", "")) else "",
                    str(row.get("experience", "")) if pd.notna(row.get("experience", "")) else "",
                    str(row.get("location", "")) if pd.notna(row.get("location", "")) else "",
                    str(row.get("application_url", "")) if pd.notna(row.get("application_url", "")) else "",
                    str(row.get("deadline", "")) if pd.notna(row.get("deadline", "")) else "",
                ),
            )
        db.commit()
        flash("Dataset reloaded from CSV.", "success")
    else:
        flash("Dataset file not found.", "danger")
    return redirect(url_for("admin_opportunities"))


# ---------------------------------------------------------------------------
# Context + startup
# ---------------------------------------------------------------------------

@app.context_processor
def inject_globals():
    now = datetime.now().strftime("%Y-%m-%d, %H:%M")
    return {"current_datetime": now, "types": OPPORTUNITY_TYPES}


with app.app_context():
    init_db()


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)