# AI-Powered Opportunity Recommendation & Skill Gap Analysis Agent

An intelligent web system that analyzes a user's profile (skills, education, interests, experience,
career goals) using **TF-IDF + Cosine Similarity** and recommends the most relevant internships,
jobs, hackathons, scholarships, courses and certifications — ranked by a weighted match score,
with **explanations** ("why this opportunity?"), **skill-gap analysis** and **learning recommendations**.

## Tech Stack

- **Frontend:** HTML, CSS, JavaScript, Bootstrap 5
- **Backend:** Python, Flask
- **ML / NLP:** Scikit-learn (TF-IDF, Cosine Similarity), Pandas, NumPy
- **Database:** SQLite

## Scoring Model

```
Final Score = 0.40·Skill + 0.20·Education + 0.15·Interest + 0.15·Experience + 0.10·Location
```

Each component is a normalized 0–1 similarity, combined into a 0–100% match score.

## Project Structure

```
opportunity-agent/
├── app.py                  # Flask app (auth, profile, dashboard, admin)
├── requirements.txt
├── dataset/
│   └── opportunities.csv   # ~60 seed opportunities
├── database/
│   └── database.db         # created automatically on first run
├── ml/
│   ├── recommender.py      # TF-IDF + cosine + weighted scoring + skill gap
│   └── __init__.py
├── static/
│   ├── css/style.css
│   └── js/script.js
└── templates/              # base, auth, dashboard, detail, skill-gap, admin, ...
```

## Run Locally

```bash
cd opportunity-agent
python -m pip install -r requirements.txt
python app.py
```

Open http://localhost:5000

- Register a student account, then build your profile (skills, education, branch,
  interests, preferred role, location).
- The **Dashboard** shows your top ranked opportunities.
- **Recommendations** adds filters (type, location, experience, skill).
- **Opportunity detail** shows match breakdown, "why this opportunity?" and skill gap + learning resources.
- **Skill Gap** gives a full gap report across your top matches.

### Demo Admin

| Email             | Password   |
|-------------------|------------|
| admin@example.com | admin123   |

Admin can add/edit/delete opportunities, view users and applications, and reload the CSV dataset.

## Key Pages

`/register` `/login` `/profile` `/dashboard` `/recommendations` `/opportunities`
`/opportunity/<id>` `/opportunity/<id>/apply` `/applications` `/skill-gap` `/admin`

## Notes

- Percentages are recommendation-system scores, not guarantees of eligibility.
- Add more rows to `dataset/opportunities.csv` (or via the admin panel) for richer results,
  then use "Reload from CSV" in the admin panel.