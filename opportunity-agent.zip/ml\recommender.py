"""Opportunity Recommendation Engine.

Content-based recommender that uses:
  - TF-IDF vectorization + cosine similarity for semantic text matching
  - weighted component scoring (skill / education / interest / experience / location)
  - skill-gap analysis and personalized learning recommendations
"""

import re

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

WEIGHTS = {
    "skill": 0.40,
    "education": 0.20,
    "interest": 0.15,
    "experience": 0.15,
    "location": 0.10,
}

SYNONYMS = {
    "ml": "machine learning",
    "ai": "artificial intelligence",
    "nlp": "natural language processing",
    "js": "javascript",
    "ts": "typescript",
    "cpp": "c plus plus",
    "c++": "c plus plus",
    "k8s": "kubernetes",
    "gcp": "google cloud platform",
    "cv": "computer vision",
}

BRANCH_SYNONYMS = {
    "cse": "computer science",
    "cs": "computer science",
    "it": "information technology",
    "ece": "electronics and communication",
    "eee": "electrical and electronics",
    "ee": "electrical engineering",
    "mech": "mechanical",
    "ai": "artificial intelligence",
}

LEVELS = {
    "fresher": 0,
    "student": 0,
    "beginner": 0,
    "entry level": 0,
    "intern": 0,
    "trainee": 0,
    "intermediate": 2,
    "advanced": 3,
    "expert": 4,
}

LEARNING_RESOURCES = {
    "python": [
        ("Python for Everybody (Coursera)", "https://www.coursera.org/specializations/python"),
        ("Learn Python - Codecademy", "https://www.codecademy.com/learn/learn-python-3"),
        ("Python Official Tutorial", "https://docs.python.org/3/tutorial/"),
    ],
    "machine learning": [
        ("Machine Learning Specialization (Coursera)", "https://www.coursera.org/specializations/machine-learning-introduction"),
        ("Machine Learning Crash Course (Google)", "https://developers.google.com/machine-learning/crash-course"),
        ("Kaggle Intro to Machine Learning", "https://www.kaggle.com/learn/intro-to-machine-learning"),
    ],
    "deep learning": [
        ("Deep Learning Specialization (Coursera)", "https://www.coursera.org/specializations/deep-learning"),
        ("fast.ai Practical Deep Learning", "https://course.fast.ai/"),
        ("CS231n: CNNs for Visual Recognition", "https://cs231n.github.io/"),
    ],
    "tensorflow": [
        ("TensorFlow Developer Certificate", "https://www.coursera.org/professional-certificates/tensorflow-in-practice"),
        ("TensorFlow Documentation", "https://www.tensorflow.org/learn"),
    ],
    "pytorch": [
        ("PyTorch Official Tutorials", "https://pytorch.org/tutorials/"),
        ("Deep Learning with PyTorch", "https://www.coursera.org/learn/deep-neural-networks-with-pytorch"),
    ],
    "natural language processing": [
        ("NLP Specialization (Coursera)", "https://www.coursera.org/specializations/natural-language-processing"),
        ("Hugging Face NLP Course", "https://huggingface.co/learn/nlp-course"),
    ],
    "computer vision": [
        ("CS231n Course Notes", "https://cs231n.github.io/"),
        ("OpenCV Courses", "https://opencv.org/university/"),
    ],
    "flask": [
        ("Flask Mega-Tutorial (Miguel Grinberg)", "https://blog.miguelgrinberg.com/post/the-flask-mega-tutorial-part-i-hello-world"),
        ("Flask Documentation", "https://flask.palletsprojects.com/"),
    ],
    "django": [
        ("Django Official Tutorial", "https://docs.djangoproject.com/en/stable/intro/tutorial01/"),
        ("MDN Django Web Framework", "https://developer.mozilla.org/en-US/docs/Learn/Server-side/Django"),
    ],
    "sql": [
        ("SQL for Data Science (Coursera)", "https://www.coursera.org/learn/sql-for-data-science"),
        ("SQLBolt - Interactive SQL", "https://sqlbolt.com/"),
    ],
    "javascript": [
        ("JavaScript Course (freeCodeCamp)", "https://www.freecodecamp.org/learn/javascript-algorithms-and-data-structures/"),
        ("The Modern JavaScript Tutorial", "https://javascript.info/"),
    ],
    "react": [
        ("React Documentation", "https://react.dev/learn"),
        ("Scrimba Learn React", "https://scrimba.com/learn/learnreact"),
    ],
    "node.js": [
        ("Node.js Official Docs", "https://nodejs.org/en/learn"),
        ("Node.js Course (Coursera)", "https://www.coursera.org/learn/server-side-development-with-nodejs"),
    ],
    "html": [
        ("HTML Tutorial (W3Schools)", "https://www.w3schools.com/html/"),
        ("MDN HTML Basics", "https://developer.mozilla.org/en-US/docs/Learn/HTML"),
    ],
    "css": [
        ("MDN CSS Basics", "https://developer.mozilla.org/en-US/docs/Learn/CSS"),
        ("freeCodeCamp Responsive Web Design", "https://www.freecodecamp.org/learn/2022/responsive-web-design/"),
    ],
    "java": [
        ("Java Programming (Coursera)", "https://www.coursera.org/specializations/java-programming"),
        ("Java Official Tutorials", "https://docs.oracle.com/javase/tutorial/"),
    ],
    "kotlin": [
        ("Kotlin Official Docs", "https://kotlinlang.org/docs/home.html"),
        ("Android Basics in Kotlin", "https://developer.android.com/courses/android-basics-kotlin/course"),
    ],
    "c plus plus": [
        ("C++ Course (LearnCpp)", "https://www.learncpp.com/"),
        ("C++ for Programmers (edX)", "https://www.edx.org/learn/c-plus-plus"),
    ],
    "go": [
        ("Go by Example", "https://gobyexample.com/"),
        ("A Tour of Go", "https://go.dev/tour/"),
    ],
    "aws": [
        ("AWS Skill Builder", "https://aws.amazon.com/training/digital/"),
        ("AWS Cloud Practitioner Essentials (Coursera)", "https://www.coursera.org/learn/aws-cloud-practitioner-essentials"),
    ],
    "docker": [
        ("Docker Official Docs", "https://docs.docker.com/get-started/"),
        ("Docker & Kubernetes Course (Udemy)", "https://www.udemy.com/course/docker-mastery/"),
    ],
    "kubernetes": [
        ("Kubernetes Fundamentals (KodeKloud)", "https://kodekloud.com/courses/kubernetes-for-the-absolute-beginners/"),
        ("Kubernetes Official Docs", "https://kubernetes.io/docs/tutorials/"),
    ],
    "statistics": [
        ("Statistics with Python (Coursera)", "https://www.coursera.org/specializations/statistics-with-python"),
        ("Khan Academy Statistics", "https://www.khanacademy.org/math/statistics-probability"),
    ],
    "pandas": [
        ("Pandas Data Structures (Kaggle)", "https://www.kaggle.com/learn/pandas"),
        ("Pandas User Guide", "https://pandas.pydata.org/docs/user_guide/index.html"),
    ],
    "excel": [
        ("Excel Skills for Business (Coursera)", "https://www.coursera.org/specializations/excel"),
        ("Microsoft Excel Support", "https://support.microsoft.com/en-us/excel"),
    ],
    "tableau": [
        ("Tableau Training & Tutorials", "https://www.tableau.com/learn/training"),
        ("Data Visualization with Tableau (Coursera)", "https://www.coursera.org/specializations/data-visualization"),
    ],
    "power bi": [
        ("Power BI Guided Learning", "https://learn.microsoft.com/en-us/training/powerplatform/power-bi"),
        ("Microsoft Power BI Courses", "https://learn.microsoft.com/en-us/training/browse/?products=power-bi"),
    ],
    "linux": [
        ("Linux Basics (Udacity)", "https://www.udacity.com/course/linux-command-line-basics--ud595"),
        ("Linux Journey", "https://linuxjourney.com/"),
    ],
    "cybersecurity": [
        ("Introduction to Cyber Security (Coursera)", "https://www.coursera.org/learn/intro-cyber-security"),
        ("TryHackMe", "https://tryhackme.com/"),
    ],
    "ethical hacking": [
        ("Certified Ethical Hacker Path", "https://www.eccouncil.org/train-certify/certified-ethical-hacker-ceh/"),
        ("TryHackMe", "https://tryhackme.com/"),
    ],
    "spring boot": [
        ("Spring Boot Quickstart", "https://spring.io/quickstart"),
        ("Spring Framework Tutorial (Baeldung)", "https://www.baeldung.com/spring-boot"),
    ],
    "cloud computing": [
        ("Cloud Computing Courses (Coursera)", "https://www.coursera.org/browse/information-technology/cloud-computing"),
        ("AWS Cloud Practitioner Essentials", "https://www.coursera.org/learn/aws-cloud-practitioner-essentials"),
    ],
    "data structures": [
        ("Data Structures & Algorithms (Coursera)", "https://www.coursera.org/specializations/data-structures-algorithms"),
        ("GeeksforGeeks DSA", "https://www.geeksforgeeks.org/"),
    ],
    "algorithms": [
        ("Algorithms Specialization (Coursera)", "https://www.coursera.org/specializations/algorithms"),
        ("GeeksforGeeks DSA", "https://www.geeksforgeeks.org/"),
    ],
}


# ---------------------------------------------------------------------------
# Text helpers
# ---------------------------------------------------------------------------

def _tok(s):
    """Lowercase and tokenize a string into meaningful words."""
    s = s.lower().replace("+", " plus ").replace("/", " ")
    return [w for w in re.split(r"[^a-z0-9]+", s) if len(w) >= 2]


def normalize_skill(skill):
    """Return a canonical, comparable form of a skill name."""
    s = str(skill).strip().lower()
    for key, val in SYNONYMS.items():
        if s == key:
            return val
    return " ".join(_tok(s))


def parse_skills(skills_str):
    """Parse a comma/newline separated skills string into a list of skills."""
    if isinstance(skills_str, (list, tuple)):
        parts = list(skills_str)
    else:
        parts = re.split(r"[,\n;]", str(skills_str or ""))
    out, seen = [], set()
    for p in parts:
        p = normalize_skill(p)
        if p and p not in seen:
            seen.add(p)
            out.append(p)
    return out


def skill_matches(user_skill, opp_skill):
    """True when a user skill is considered present in an opportunity skill."""
    if user_skill == opp_skill:
        return True
    a = set(user_skill.split())
    b = set(opp_skill.split())
    if a & b and (len(a) > 1 or len(b) > 1):
        return True
    return user_skill in opp_skill or opp_skill in user_skill


def education_terms(text):
    """Keyword terms (degree + branch) extracted from an education string."""
    text = str(text or "")
    terms = set(_tok(text))
    for t in list(terms):
        if t in BRANCH_SYNONYMS:
            terms.add(BRANCH_SYNONYMS[t])
    return terms


def parse_experience(text):
    """Convert an experience requirement string into a level integer."""
    t = str(text or "").strip().lower()
    for kw, level in LEVELS.items():
        if kw in t:
            return level
    if re.search(r"\b4\s*\+", t) or re.search(r"\b5\b", t) or "4+" in t:
        return 4
    if re.search(r"\b3\b", t) or "2-4" in t:
        return 3
    if re.search(r"\b2\b", t) or "1-2" in t or "1+" in t:
        return 2
    if re.search(r"\b1\b", t) or "0-1" in t:
        return 1
    return 0


USER_EXPERIENCE_LEVELS = {
    "Fresher": 0,
    "0-1 years": 1,
    "1-2 years": 2,
    "2-4 years": 3,
    "4+ years": 4,
}


def experience_score(user_level, opp_level):
    if not opp_level:
        return 1.0
    if user_level >= opp_level:
        return 1.0
    if user_level >= opp_level - 1:
        return 0.5
    return 0.0


def location_score(user_loc, opp_loc):
    u = str(user_loc or "").strip().lower()
    o = str(opp_loc or "").strip().lower()
    if not u or not o:
        return 1.0
    flex = {"remote", "online", "anywhere", "nationwide", "any", "all"}
    if u in flex or o in flex:
        return 1.0
    if u in o or o in u:
        return 1.0
    return 0.0


def match_fraction(user_terms, opp_text):
    if not user_terms:
        return 0.0
    ot = str(opp_text or "").lower()
    if not ot:
        return 0.0
    matched = sum(1 for t in user_terms if t in ot)
    return matched / len(user_terms)


# ---------------------------------------------------------------------------
# TF-IDF cosine similarity
# ---------------------------------------------------------------------------

def _cosine_similarity_scores(query_doc, corpus_docs):
    if not corpus_docs:
        return []
    docs = [query_doc or " "] + [d or " " for d in corpus_docs]
    vectorizer = TfidfVectorizer(stop_words="english")
    try:
        matrix = vectorizer.fit_transform(docs)
    except ValueError:
        return [0.0] * len(corpus_docs)
    sims = cosine_similarity(matrix[0:1], matrix[1:]).flatten()
    return [float(x) for x in sims]


# ---------------------------------------------------------------------------
# Core recommendation
# ---------------------------------------------------------------------------

def build_user_document(user):
    """Combine the user profile into a single text document."""
    parts = [
        user.get("skills"),
        user.get("programming_languages"),
        user.get("education"),
        user.get("degree"),
        user.get("branch"),
        user.get("interests"),
        user.get("preferred_role"),
        user.get("work_type"),
    ]
    return " ".join(str(p or "") for p in parts)


def build_opportunity_document(opp):
    """Combine an opportunity into a single text document."""
    parts = [
        opp["title"],
        opp["skills"],
        opp["education"],
        opp["description"],
        opp["type"],
        str(opp.get("company") or ""),
    ]
    return " ".join(str(p or "") for p in parts)


def score_opportunity(user, opp, semantic_scores=None, idx=0):
    """Compute the weighted recommendation score + explanation for one row.

    user: dict with keys skills, programming_languages, education, degree,
          branch, interests, preferred_role, location, experience, work_type
    opp : pandas Series / dict with keys title, skills, education, experience,
          location, description, type, ...
    """
    user_skills = parse_skills(user.get("skills"))
    user_skills += parse_skills(user.get("programming_languages"))
    seen = set()
    user_skills = [s for s in user_skills if not (s in seen or seen.add(s))]

    opp_skills = parse_skills(opp["skills"])

    # Component 1: skill match (explicit overlap + semantic boost)
    matched_skills = [s for s in user_skills if any(skill_matches(s, os) for os in opp_skills)]
    skill_overlap = len(matched_skills) / max(len(user_skills), 1)
    semantic = semantic_scores[idx] if semantic_scores is not None else 0.0
    skill_score = 0.85 * skill_overlap + 0.15 * semantic

    # Component 2: education match
    user_edu_terms = education_terms(
        " ".join([user.get("education", ""), user.get("degree", ""), user.get("branch", "")])
    )
    edu_score = match_fraction(user_edu_terms, " ".join([opp["education"], opp["description"]]))

    # Component 3: interest match (TF-IDF over interest text vs opp text)
    interest_query = " ".join([
        str(user.get("interests", "")),
        str(user.get("preferred_role", "")),
        str(user.get("work_type", "")),
    ]).strip()
    if interest_query:
        corpus = [build_opportunity_document(opp)]
        interest_score = _cosine_similarity_scores(interest_query, corpus)[0]
    else:
        interest_score = semantic

    # Component 4: experience match
    user_level = USER_EXPERIENCE_LEVELS.get(str(user.get("experience", "")).strip(), 0)
    opp_level = parse_experience(opp["experience"])
    exp_score = experience_score(user_level, opp_level)

    # Component 5: location match
    loc_score = location_score(user.get("location"), opp["location"])

    components = {
        "skill": skill_score,
        "education": edu_score,
        "interest": min(interest_score, 1.0),
        "experience": exp_score,
        "location": loc_score,
    }

    final_score = sum(WEIGHTS[k] * components[k] for k in WEIGHTS) * 100
    final_score = round(min(final_score, 100.0), 1)

    # ----- explanation (why this opportunity?) -----
    reasons = []
    for ms in matched_skills[:5]:
        reasons.append(f"Your skill '{ms.title() if len(ms.split()) == 1 else ms.title()}' matches a requirement")
    if edu_score > 0:
        reasons.append("Your education background matches the requirement")
    if components["interest"] >= 0.33:
        reasons.append("Your career interest / preferred role aligns with this opportunity")
    if exp_score == 1.0:
        reasons.append(f"Experience requirement ('{opp.get('experience')}') matches your level")
    elif exp_score == 0.5:
        reasons.append("Experience requirement is only slightly above your current level")
    if loc_score == 1.0:
        reasons.append(f"Location ('{opp.get('location')}') matches your preference")
    if not reasons:
        reasons.append("Recommended based on overall text similarity with your profile")

    return {
        "score": final_score,
        "components": {k: round(v * 100, 1) for k, v in components.items()},
        "semantic_similarity": round(semantic * 100, 1),
        "matched_skills": matched_skills,
        "matched_count": len(matched_skills),
        "user_skill_count": len(user_skills) or 1,
        "missing_skills": [s for s in opp_skills if not any(skill_matches(us, s) for us in user_skills)],
        "reasons": reasons,
    }


def filter_opportunities(df, filters):
    """Apply basic pre-ML filters to the opportunity dataframe."""
    result = df.copy()

    types = [t.strip() for t in (filters.get("type") or "").split(",") if t.strip()]
    if types:
        result = result[result["type"].isin(types)]

    locations = [t.strip().lower() for t in (filters.get("location") or "").split(",") if t.strip()]
    if locations:
        mask = result["location"].astype(str).str.lower().str.contains(
            "|".join(re.escape(x) for x in locations), na=False
        )
        result = result[mask]

    skills = [normalize_skill(x) for x in (filters.get("skills") or "").split(",") if x.strip()]
    if skills:
        def _has_any(r):
            opp = parse_skills(r["skills"])
            return any(
                any(skill_matches(s, os) for os in opp) for s in skills
            )
        result = result[result.apply(_has_any, axis=1)]

    exp = (filters.get("experience") or "").strip()
    if exp and exp != "Any":
        user_level = USER_EXPERIENCE_LEVELS.get(exp, -1)
        def _exp_ok(r):
            return experience_score(user_level, parse_experience(r["experience"])) >= 0.5
        result = result[result.apply(_exp_ok, axis=1)]

    edu = (filters.get("education") or "").strip()
    if edu and edu != "Any":
        terms = education_terms(edu)
        if terms:
            def _edu_ok(r):
                return match_fraction(terms, " ".join([r["education"], r["description"]])) > 0
            result = result[result.apply(_edu_ok, axis=1)]

    q = (filters.get("q") or "").strip().lower()
    if q:
        mask = result.apply(
            lambda r: q in str(r["title"]).lower()
            or q in str(r["description"]).lower()
            or q in str(r["skills"]).lower(),
            axis=1,
        )
        result = result[mask]

    return result


def recommend_opportunities(user, opportunities, top_n=10, filters=None):
    """Return ranked, scored opportunities for a user profile.

    user          : dict of user profile fields
    opportunities : DataFrame of opportunities
    top_n         : number of results to return
    filters       : optional dict of pre-filters (type, location, skills, ...)
    """
    df = filter_opportunities(opportunities, filters) if filters else opportunities
    if df.empty:
        return []

    user_doc = build_user_document(user)
    corpus = [build_opportunity_document(opp) for _, opp in df.iterrows()]
    semantic_scores = _cosine_similarity_scores(user_doc, corpus)

    results = []
    for idx, (_, opp) in enumerate(df.iterrows()):
        rating = score_opportunity(user, opp, semantic_scores, idx)
        item = rating
        item["id"] = opp.get("id")
        item["title"] = opp["title"]
        item["company"] = opp.get("company") or ""
        item["type"] = opp["type"]
        item["skills"] = opp["skills"]
        item["education"] = opp["education"]
        item["experience"] = opp["experience"]
        item["location"] = opp["location"]
        item["description"] = opp.get("description") or ""
        item["application_url"] = opp.get("application_url") or ""
        item["deadline"] = opp.get("deadline") or ""
        results.append(item)

    results.sort(key=lambda r: r["score"], reverse=True)
    return results[:top_n]


def get_skill_gap(user_skills, opp_skills):
    """Return matched + missing skills between a user and an opportunity."""
    user_skills = parse_skills(user_skills)
    opp_skills = parse_skills(opp_skills)
    matched = [s for s in user_skills if any(skill_matches(s, os) for os in opp_skills)]
    missing = [s for s in opp_skills if not any(skill_matches(us, s) for us in user_skills)]
    return matched, missing


def learning_recommendations(missing_skills):
    """Map missing skills to learning resources."""
    output = []
    for s in missing_skills:
        key = s
        if key not in LEARNING_RESOURCES:
            key = next((k for k in LEARNING_RESOURCES if skill_matches(key, k)), None)
        if key:
            output.append({"skill": s, "resources": LEARNING_RESOURCES[key]})
        else:
            output.append({
                "skill": s,
                "resources": [(
                    f"Search courses for {s.title()}",
                    f"https://www.coursera.org/search?query={s.replace(' ', '+')}",
                )],
            })
    return output