// Opportunity Agent - small UI helpers
document.addEventListener('DOMContentLoaded', function () {
    // Confirm delete actions
    document.querySelectorAll('[data-confirm]').forEach(function (el) {
        el.addEventListener('click', function (e) {
            if (!window.confirm(el.getAttribute('data-confirm'))) {
                e.preventDefault();
            }
        });
    });

    // Auto-close alerts
    setTimeout(function () {
        document.querySelectorAll('.alert-dismissible').forEach(function (a) {
            var bs = window.bootstrap && bootstrap.Alert;
            if (bs) new bs(a).close();
        });
    }, 5000);
});